﻿using System;
using System.Windows.Forms;

using ICSharpCode.Core;
using ICSharpCode.SharpDevelop;
using ICSharpCode.SharpDevelop.Gui;

namespace $safeprojectname$
{
    /// <summary>
    /// Description of MenuCommand
    /// </summary>
    public class MenuCommand : AbstractMenuCommand
    {
        /// <summary>
        /// Starts the command
        /// </summary>
        public override void Run()
        {
            // TODO: Add your code here !!!
            //WorkbenchSingleton.Workbench.ShowView(new View1());
        }
    }
}