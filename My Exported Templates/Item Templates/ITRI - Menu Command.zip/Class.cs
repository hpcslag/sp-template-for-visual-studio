﻿using System;
using System.Windows.Forms;

using ICSharpCode.Core;
using ICSharpCode.SharpDevelop;

namespace $rootnamespace$
{
	/// <summary>
	/// Description of $safeitemrootname$
	/// </summary>
	public class $safeitemrootname$ : AbstractMenuCommand
	{
		/// <summary>
		/// Starts the command
		/// </summary>
		public override void Run()
		{
			// TODO: Add your code here !!!
		}
	}
}