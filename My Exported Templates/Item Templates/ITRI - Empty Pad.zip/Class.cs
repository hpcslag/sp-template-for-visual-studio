﻿using System;
using System.Windows.Forms;
using ICSharpCode.Core;
using ICSharpCode.SharpDevelop.Gui;

namespace $rootnamespace$
{
	/// <summary>
	/// Description of the pad content
	/// </summary>
	public class $safeitemrootname$ : AbstractPadContent
	{
		Panel ctl;

		/// <summary>
		/// Creates a new $safeitemrootname$ object
		/// </summary>
		public $safeitemrootname$()
		{
			ctl = new Panel();
			// TODO: Initialize the panel's content.
		}

		/// <summary>
		/// The <see cref="System.Windows.Forms.Control"/> representing the pad
		/// </summary>
		public override Control Control
		{
			get
			{
				return ctl;
			}
		}

		/// <summary>
		/// Refreshes the pad
		/// </summary>
		public override void RedrawContent()
		{
			// TODO: Refresh the whole pad control here, renew all resource strings whatever
			//       Note that you do not need to recreate the control.
		}

		/// <summary>
		/// Cleans up all used resources
		/// </summary>
		public override void Dispose()
		{
			ctl.Dispose();
			base.Dispose();
		}
	}
}
