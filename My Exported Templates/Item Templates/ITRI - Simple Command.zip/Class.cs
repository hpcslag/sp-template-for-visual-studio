﻿using System;
using System.Windows.Forms;

using ICSharpCode.Core;

namespace $rootnamespace$
{
	/// <summary>
	/// Description of $safeitemrootname$
	/// </summary>
	public class $safeitemrootname$ : AbstractCommand
	{
		/// <summary>
		/// Starts the command
		/// </summary>
		public override void Run()
		{
			// TODO: Add your code here !!!
		}
	}
}