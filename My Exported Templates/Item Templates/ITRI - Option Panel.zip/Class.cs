﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

using ICSharpCode.SharpDevelop.Internal.ExternalTool;
using ICSharpCode.Core;
using ICSharpCode.SharpDevelop.Gui;

namespace $rootnamespace$
{
	/// <summary>
	/// Summary of $safeitemrootname$
	/// </summary>
	public class $safeitemrootname$ : AbstractOptionPanel
	{
		public override void LoadPanelContents()
		{
			// TODO initialize the panel here
		}

		public override bool StorePanelContents()
		{
			// TODO save your options here
			return true;
		}
	}
}