﻿using System;
using System.Windows.Forms;
using ICSharpCode.SharpDevelop.Gui;

namespace $rootnamespace$
{
	/// <summary>
	/// Description of the view content
	/// </summary>
	public class $safeitemrootname$ : AbstractViewContent
	{
		/// <summary>
		/// The <see cref="System.Windows.Forms.Control"/> representing the view
		/// </summary>
		public override object Control
        {
            get
            {
                //
                // TODO : Give back a working Windows.Forms Control
                //
                return null; //return some view
            }
        }

        /// <summary>
        /// Creates a new $safeitemrootname$ object
        /// </summary>
        public $safeitemrootname$()
		{
			this.TitleName = "$safeitemrootname$";
		}

        /// <summary>
        /// Loads a new file into MyView
        /// </summary>
        /*public override void Load(string fileName)
        {
            // TODO
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Refreshes the view
        /// </summary>
        public override void RedrawContent()
        {
            // TODO: Refresh the whole view control here, renew all resource strings
            //       Note that you do not need to recreate the control.
        }*/

        /// <summary>
        /// Cleans up all used resources
        /// </summary>
        public override void Dispose()
        {
            // TODO: Clean up resources in this method
            // Control.Dispose();
            base.Dispose();
        }
	}
}
