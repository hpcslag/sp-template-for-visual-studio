﻿using System;
using ICSharpCode.Core;

namespace $rootnamespace$
{
	public class $safeitemrootname$
	{
		public const string OptionsProperty = "$rootnamespace$.Options";

		static Properties properties;

		static $safeitemrootname$()
		{
			properties = PropertyService.GetProperty(OptionsProperty, new Properties());
		}

		public static event PropertyChangedEventHandler PropertyChanged
		{
			add { properties.PropertyChanged += value; }
			remove { properties.PropertyChanged -= value; }
		}
		
//		public static string MyStringProperty {
//			get {
//				return properties.GetProperty("MyStringProperty", "DefaultValue");
//			}
//			set {
//				properties.SetProperty("MyStringProperty", value);
//			}
//		}
	}
}
